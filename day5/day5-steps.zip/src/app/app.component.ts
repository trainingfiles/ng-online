import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone : true,
  template : `<div> 
              <h2>Welcome to Angular</h2> 
              <h3>{{title}}</h3>
              <ul>
                  <li>List Item 1</li>
                  <li>List Item 2</li>
                  <li>List Item 3</li>
                  <li>List Item 4</li>
                  <li>List Item 5</li>
              </ul>
            </div>
` 
})
export class AppComponent {
  title = 'steps';
}
