import { Component } from '@angular/core';
import { Login } from './login';

@Component({
  selector: 'app-root',
  template : `
  <h1 [innerHTML]="title"></h1>
  <h1 [innerHTML]="message1"></h1>
  <h1 [innerHTML]="message2"></h1>
  <input #ti1 type="text" [value]="title" (input)="alertHandler(ti1.value)"/>
  <br>
  <input #ti2 [value]="title" (input)="title = ti2.value"/>
  <br>
  <input [(ngModel)]="title"/>
  <h2>{{title}}</h2>
  <input type="range" [(ngModel)]="power">{{ power }}
  <app-child [herovalue]="title" [heropower]="power" (childevent)="childEventListener($event)">
    {{title}}
    <h1>Heading 1</h1>
    <h2>Heading 2</h2>
    <h3>Heading 3</h3>
    <ul>
      <li>List Item 1</li>
      <li>List Item 2</li>
      <li>List Item 3</li>
      <li>List Item 4</li>
      <li>List Item 5</li>
    </ul>
    <button>Click Me</button>
    <p>
      First Paragraph
      <br>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus quisquam laborum ipsam? Fugit nam sint repudiandae exercitationem officia. Sequi quo facilis maiores, et molestiae dolore placeat nihil quia mollitia omnis.
    </p>
    <p class="player">
      Second Paragraph
      <br>
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. Optio ea quo quis, eius, quasi dolores aspernatur quidem officiis pariatur molestiae doloremque veniam nostrum assumenda, quaerat minus sint voluptatibus quam tenetur.
    </p>
  </app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-communication';
  power = 0;
  message1 = "default firstname";
  message2 = "default lastname";

  alertHandler(ntextvalue:any){
    this.title = ntextvalue;
    // alert("changed")
  } 

  childEventListener(evt:Login){
    // alert(evt);
    // this.message = evt
    this.message1 = evt.firstname;
    this.message2 = evt.lastname;
  }
}
