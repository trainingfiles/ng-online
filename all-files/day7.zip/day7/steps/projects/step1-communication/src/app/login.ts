export class Login{
    constructor(public firstname:string, public lastname:string){
        // empty
    }
}