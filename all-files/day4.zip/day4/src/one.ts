let message:string = "Welcome to your life";

/* 
string
boolean
number

*/

alert(message);