let init = function(){
    console.log("log from init");
};
export default  init ;