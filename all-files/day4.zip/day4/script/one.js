"use strict";
let message = "Welcome to your life";
alert(message);
