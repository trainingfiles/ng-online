import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "gen"
})
export class GenPipe implements PipeTransform{
    // transform(...args){
    transform(label:any, gender:any){
        // return args[0]+" hello from Gen Pipe "+args[1]
        if(gender === "female"){
            return "Miss "+label
        }else{
            return "Mr "+label
        }
    }
}