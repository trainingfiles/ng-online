import { Component } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  template: ` 
  <div class="container">
    <h1>{{ title }}</h1> 
    <div class="box">
      @for(user of appdata.data; track user.id ){
        <div class="card">
        <img [src]="user.avatar" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">{{ user.first_name+" "+user.last_name}}</h5>
          <a href="mailto:{{user.email}}" class="btn btn-primary">{{ user.email }}</a>
        </div>
      </div>
    }
    </div>
  </div>
  `,
  styles: [`
    .card{
      width : 300px;
      margin : 10px;
    }
    .card .card-img-top{
      max-width : 100px;
    }
    `],
})
export class AppComponent {
  title = 'Services with External Data';
  appdata:any = {};
  constructor(private udata:UserService){
    this.udata.getData().subscribe( res => this.appdata = res);
  }
}
