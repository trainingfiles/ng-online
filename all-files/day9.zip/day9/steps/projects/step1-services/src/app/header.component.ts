import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
   <h2>Header Component Version : {{ compversion }}</h2>
    <ul class="nav">
      @for(hero of data; track hero.sl){
            <li class="nav-item">
              <a class="nav-link" href="#">{{ hero.title }}</a>
            </li>
       }
    </ul>
  `,
  styles: ``
})
export class HeaderComponent {
  // @Input() data:any = []
  data:any = [];
  compversion = 0;
  //hs:HeroService = new HeroService();
  constructor(private hs:HeroService){
    this.data = this.hs.getdata();
    this.compversion = this.hs.getversion();
  }
}
