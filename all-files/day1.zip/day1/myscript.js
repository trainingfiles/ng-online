function init(){
    document.querySelectorAll("h1")[0].textContent = "Welcome to your life";
};