import { Component } from "@angular/core";

@Component({
    selector : "app-first",
    template : `
                <h2>I am First Component </h2>
                `
})
export class FirstComp{

}

// export { FirstComp }