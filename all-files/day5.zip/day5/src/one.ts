// let vals1 = "welcome to your life";
// string, number, boolean, array, object, interface, enums, any
// let vals2:(number | string | boolean) = 666; // union type

/* 
class Hero{
    firstname = "Default firstname";
    lastname = "Default lastname"
};

let hero1:Hero = new Hero();
let hero2:Hero = new Hero();
let hero3:Hero = new Hero();
*/

// let favNums:Array<number> = [56,98,58,74]; // generic
let favNums2:number[] = [2,8,7,6,1]; // typed array

// let avengers:Array<Hero> = [hero1, hero2, hero3];

