import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1> {{title}} </h1>
      <!-- <app-templateform></app-templateform> -->
      <!-- <app-reactivegroupform></app-reactivegroupform> -->
      <app-reactivebuilderform></app-reactivebuilderform>
    </div>
    
    
  `,
  styles: []
})
export class AppComponent {
  title = 'Forms in Angular';
}
