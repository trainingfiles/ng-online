import { Component } from "@angular/core";

@Component({
    selector : 'app-intel',
    template : `
        <div style="border: 1px solid grey; float :left; margin : 10px; padding : 10px">
        <h2 style="margin: 10px;">{{ title }}</h2>
        <input #colip (input)="selectedColor = colip.value" type="color">
        <br>
        <input #messageip (input)="compmessage = messageip.value" type="text">
        <div class="box" [style.background-color]="selectedColor">
            {{ compmessage | intel }}
        </div>
        </div>
    `,
    styles : [`
            .box{
                width : 200px;
                height : 100px;
                line-height : 100px;
                text-align : center;
                font-family : sans-serif;
            }
    `]
})
export class IntelComp{
    title = "Intel Component";
    compmessage = "component message";
    selectedColor = "";
}

