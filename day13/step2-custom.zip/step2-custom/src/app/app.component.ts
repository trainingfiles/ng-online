import { Component, contentChild } from '@angular/core';
/* 
attribute directives
<h1 *ngIf> hello </h1>  
ngIf
ngFor
ngStyle
ngClass
ng-nonbindable

tag / element directives
<ng-content></ng-content>
ng-content
router-outlet
ng-template

*/


@Component({
  selector: 'app-root',
  template: `
    <h1>Welcome to {{title}}!</h1>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <app-intel/>
    <div style="clear: both;"></div>
    <h1 intel="blue">Sample text comes here</h1>
    <h1 intel="red">Sample text comes here</h1>
    <h1>Sample text comes here</h1> 
    <h1 intel="red">Sample text comes here</h1>
    <h1>Sample text comes here</h1>
  `,
  styles: []
})
export class AppComponent {
  title = 'step2-custom';
}
