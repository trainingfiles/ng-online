import { Directive, ElementRef, Input } from "@angular/core";

/* 
attribute : [intel] | use it as <h1 intel> some content </h1>
tag / element : intel | use it as <intel> this can take multiple parameters
class    : .intel | use it as class="intel"
*/

@Directive({
    selector : "[intel]"
})
export class IntelDirective{
    @Input() intel = '';
    constructor( private er : ElementRef){
        //empty
    }
    ngOnInit(){
        this.er.nativeElement.setAttribute("style",`background-color: `+ this.intel );
        // console.log(this.er.nativeElement)
        // this.er.nativeElement.querySelector("h1").setAttribute("style","background-color: orange")
    }
}