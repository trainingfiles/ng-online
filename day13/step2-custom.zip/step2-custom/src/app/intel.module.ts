import { NgModule } from "@angular/core";
import { IntelComp } from "./intel.component";
import { IntelDirective } from "./intel.directive";
import { IntelPipe } from "./intel.pipe";

@NgModule({
    declarations: [IntelComp, IntelDirective, IntelPipe],
    exports: [IntelComp, IntelDirective, IntelPipe]
  })
  export class IntelModule { }