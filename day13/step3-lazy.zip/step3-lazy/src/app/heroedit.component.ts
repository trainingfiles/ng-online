import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroedit',
  template: `
    <p>
      heroedit works!
    </p>
  `,
  styles: []
})
export class HeroeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
