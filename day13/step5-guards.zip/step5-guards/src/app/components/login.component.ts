import { Component } from "@angular/core";

@Component({
    selector : 'app-login',
    template : `
    <div>
        <h2>{{ title }}</h2>
    </div>
    `
})
export class LoginComponent{ 
    title = "Login Component"
}