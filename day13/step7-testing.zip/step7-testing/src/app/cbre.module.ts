import { NgModule } from "@angular/core";

import { GenPipe } from "./gen.pipe";
import { CBREComp } from "./cbre.component";
import { CBREDirective } from "./cbre.directive";

@NgModule({
    declarations : [CBREComp, GenPipe, CBREDirective],
    exports : [CBREComp, GenPipe, CBREDirective]
})
export class CBREModule{

}