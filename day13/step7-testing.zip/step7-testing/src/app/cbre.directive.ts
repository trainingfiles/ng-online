import { Directive, ElementRef, Input, OnInit } from "@angular/core";

@Directive({
    selector : "[cbre]"
})
export class CBREDirective {
    // @Input('prop') select:any = "";
    // @Input() title:any = "";
    @Input() cbre:any = '';
    constructor(private elRef:ElementRef){
       // empty
    }
    ngOnInit(){
        // this.elRef.nativeElement.style.backgroundColor = "#fedfe5";
        // console.log(this.select);
        // console.log(this.title);
        this.elRef.nativeElement.addEventListener("click", this.clickHandler);
    }
    clickHandler(event:any){
        // event.target.style.backgroundColor = this.cbre+"";
        // event.target.style.backgroundColor = this.cbre+"";
        console.log(event.target.getAttribute("cbre"));
        event.target.style.backgroundColor = event.target.getAttribute("cbre")
    }
}

/* 
element directive : 'cbre'
ng-template
<ng-template></ng-template>
ng-content
<ng-content></ng-content>

class Directive  : '.cbre'

attribute directive : '[cbre]'
ngNonbindable
ngIf
ngClass
ngStyle


*/