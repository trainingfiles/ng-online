import { GenPipe } from './gen.pipe';

describe('GenPipe', () => {
  let pipe: GenPipe;

  beforeEach(() => {
    pipe = new GenPipe();
  });

  it('should transform male name correctly', () => {
    let modifiedName = pipe.transform('Phantom', 'male');
    expect(modifiedName).toBe('Mr Phantom');
  });

  it('should transform female name correctly', () => {
    let modifiedName = pipe.transform('Diana', 'female');
    expect(modifiedName).toBe('Miss Diana');
  });
});
