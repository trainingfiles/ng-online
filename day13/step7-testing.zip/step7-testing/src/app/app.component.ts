import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
  template: `
  <div class="container">
  <div style="text-align:center">
      <h1>  Custom Pipes Directive and Module </h1>
    </div>
    <table class="table table-striped table-hover table-sm table-responsive">
      <thead class="table-dark">
        <tr>
          <th>Sl#</th>
          <th>Title</th>
          <th>Photo</th>
          <th>Full Name</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
          <th>Movies List</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of heroes">
          <td>{{ hero.sl }}</td>
          <td>{{ hero.title | gen : hero.gender }}</td>
          <td>
            <img [src]="hero.poster" [alt]="hero.title" width="50">
          </td>
          <td>{{ hero.firstname+" "+hero.lastname | gen : hero.gender }}</td>
          <td>{{ hero.city }}</td>
          <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '3.2-4' }}</td>
          <td>{{ hero.releasedate | date: 'dd/MM/yyyy' }}</td>
          <td>
            <button class="masaibtn btn btn-primary">{{ hero.movieslist.length }}</button>
          </td>
        </tr>
      </tbody>
    </table>
    <hr>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
   
    <!-- This snippet is for Element  Directive
    <cbre prop="hello" title="vijay">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque ab, suscipit delectus ipsa natus ipsum obcaecati. Eveniet labore amet et dolore reprehenderit natus quis, velit molestiae, cum cumque, maxime vel!
      </p>
    </cbre>
    <br>
    <cbre prop="ola" title="batman">
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet temporibus molestias accusamus et voluptas tempora corporis ullam facilis labore maiores assumenda sequi expedita tempore sed non inventore, fugit quidem quibusdam?
      </p>
    </cbre>
    <br>
    <cbre prop="hi" title="ironman">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores quo asperiores ipsam ratione tempore provident nihil modi blanditiis, minus molestiae saepe! Recusandae omnis possimus natus vero. Distinctio vitae fugit consequuntur.
      </p>
    </cbre> 
    -->

   <!--  
    <p class="cbre">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque ab, suscipit delectus ipsa natus ipsum obcaecati. Eveniet labore amet et dolore reprehenderit natus quis, velit molestiae, cum cumque, maxime vel!
    </p>
    <p class="cbre">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet temporibus molestias accusamus et voluptas tempora corporis ullam facilis labore maiores assumenda sequi expedita tempore sed non inventore, fugit quidem quibusdam?
    </p>
    <p class="cbre">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores quo asperiores ipsam ratione tempore provident nihil modi blanditiis, minus molestiae saepe! Recusandae omnis possimus natus vero. Distinctio vitae fugit consequuntur.
    </p> 
  -->
  <div style="clear: both"></div>
    <p cbre="red">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque ab, suscipit delectus ipsa natus ipsum obcaecati. Eveniet labore amet et dolore reprehenderit natus quis, velit molestiae, cum cumque, maxime vel!
    </p>
    <p cbre="orange">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eveniet temporibus molestias accusamus et voluptas tempora corporis ullam facilis labore maiores assumenda sequi expedita tempore sed non inventore, fugit quidem quibusdam?
    </p>
    <p cbre="yellow">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores quo asperiores ipsam ratione tempore provident nihil modi blanditiis, minus molestiae saepe! Recusandae omnis possimus natus vero. Distinctio vitae fugit consequuntur.
    </p> 

  </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-custom';
  heroes:any = [];

  constructor( private hs:HeroService){}
  ngOnInit(){
    this.heroes = this.hs.getData();
  }
}
