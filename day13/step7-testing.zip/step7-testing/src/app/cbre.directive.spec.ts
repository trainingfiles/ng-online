import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { CBREDirective } from './cbre.directive';

@Component({
  template: `<div [cbre]="color">Test</div>`
})
class TestComponent {
 color = 'blue';
  onClick() {
    // Click event handler
  }
}

describe('CBREDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let divElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, CBREDirective]
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    divElement = fixture.debugElement.query(By.directive(CBREDirective));
    fixture.detectChanges();
  });

  it('should set background color on click', () => {
    const nativeElement = divElement.nativeElement;
    nativeElement.click();

    //  expect(nativeElement.style.backgroundColor).toBe('blue');
    expect(nativeElement.style.backgroundColor).toEqual('');
  });
});
