import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CBREModule } from './cbre.module';
import { HeroService } from './hero.service';


@NgModule({
  declarations: [ AppComponent ],
  imports: [ BrowserModule, CBREModule ],
  providers: [HeroService],
  bootstrap: [AppComponent]
})
export class AppModule { }
