import { Component } from '@angular/core';
import { HeroHttpService } from './hero.service';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
    <h1>Welcome to {{title}}!</h1>
    <button (click)="clickHandler()" class="btn btn-primary" type="button">Get Data</button>
    <table class="table">
      <thead  class="table-dark">
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>Poster</th>
          <th>Full Name</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
          <th>Movies List</th>
        </tr>
      </thead>
      <tbody>
          @for(hero of data.herolist; track hero.sl){
                <tr>
                <td>{{ hero.sl }}</td>
                <td>{{ hero.title | uppercase | lowercase | titlecase }}</td>
                <td>
                    <img width="50" [src]="hero.poster" [alt]="hero.title">
                </td>
                <td>{{ hero.firstname+" "+hero.lastname }}</td>
                <td>{{ hero.city }}</td>
                <td>{{ hero.ticketprice | currency : "INR" : "code" : "1.2-3" }}</td>
                <td>{{ hero.releasedate | date : "dd - MMMM - yyyy" }}</td>
                <td>
                  @for(movie of hero.movieslist; track movie.title){
                    <img class="m-1" width="50" src="{{movie.poster}}" [alt]="movie.title">
                  }
              </td>
            </tr>
            }
      </tbody>
    </table>
    </div>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-http-server';
  data:any = [];
  constructor(private hs:HeroHttpService){
    // empty
  }
  clickHandler(){
    // alert("do you want the data");
    this.hs.getHeroData().subscribe( res => this.data = res )
  }
}
