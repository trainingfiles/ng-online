import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class HeroHttpService{
    constructor(private http:HttpClient){
        // empty
    }
    getHeroData(){
        return this.http.get("http://localhost:5050/");
    }
}