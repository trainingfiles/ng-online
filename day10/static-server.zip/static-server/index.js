const express = require("express");
const cors = require("cors");

const app = express();
// app.use(cors()); // middleware
var corsOptions = {
    origin: "http://localhost:4200"
};

app.use(cors(corsOptions)); // middleware

app.get("/",function(req, res){
    // res.send("hello from express");
    res.sendFile(__dirname+"/data/data.json");
});

app.listen(5050,"localhost",function(error){
    if(error){console.log("Error ", error)}
    else{ console.log("static server is now live on localhost:5050")}
});