import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  template: `
    <h3>
      404 : Requested Page Not Found
    </h3>
  `,
  styles: ``
})
export class NotfoundComponent {

}
