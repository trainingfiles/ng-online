// http://localhost:4200/

import { Route, Routes } from "@angular/router"
import { HomeComponent } from "./home.component"
import { BatmanComponent } from "./batman.component"
import { SupermanComponent } from "./superman.component"
import { WonderwomenComponent } from "./wonderwomen.component"
import { CyborgComponent } from "./cyborg.component"
import { NotfoundComponent } from "./notfound.component"

/* Route */
let homeRoute:Route = { path : "", component:HomeComponent }// default route
let batmanRoute:Route = { path : "batman", component:BatmanComponent }// named route
let supermanRoute:Route = { path : "superman", component:SupermanComponent }// named route
let wonderwomenRoute:Route = { path : "wonderwomen", component:WonderwomenComponent }// named route
let cyborgRoute:Route = { path : "cyborg", component:CyborgComponent }// named route
let flashRoute:Route = { path : "flash", redirectTo:"batman", pathMatch:"full" }// named route
let notfoundRoute:Route = { path : "**", component:NotfoundComponent }// wildcard route

/* Routes */
let myappRoutes:Routes = [homeRoute, batmanRoute, supermanRoute, wonderwomenRoute, cyborgRoute, flashRoute, notfoundRoute]

export {myappRoutes}