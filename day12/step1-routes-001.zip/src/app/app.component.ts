import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Welcome to {{title}}!</h1>
      <ul class="nav">
        <li class="nav-item"> <a class="nav-link active" routerLink="">Home Page</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="batman">Batman</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="superman">Superman</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="wonderwomen">Wonder Women</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="cyborg">Cyborg</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="flash">Flash</a>  </li>
        <li class="nav-item"> <a class="nav-link active" routerLink="aquaman">Aquaman</a>  </li>
      </ul>
      <hr>
      <router-outlet></router-outlet>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Angular Routes';
}
