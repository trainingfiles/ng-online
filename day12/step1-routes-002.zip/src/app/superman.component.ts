import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-superman',
  template: `
    <h2> Superman Component works! </h2>
    <h3>Quantity : {{ stock==="" ? "not sent" : stock }}</h3>
    <article>
      <div>Qui iusto doloribus accusantium error. Aut cum, reiciendis iure nemo natus ab minima sequi error blanditiis temporibus dicta incidunt quia itaque optio architecto magnam animi unde, voluptate quam! Commodi, tempore.</div>
      <div>Iusto, ab harum expedita. Repellat perspiciatis rem sequi quibusdam deserunt, sapiente enim numquam eligendi, voluptas pariatur voluptates vero ab, iusto sunt. Fuga temporibus cupiditate accusantium doloribus, suscipit ab distinctio dolore!</div>
      <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro minus voluptas voluptates fugit voluptatibus aliquid soluta eveniet, ipsum facilis reiciendis! Sequi nisi fugiat tenetur architecto quo, molestiae officiis repellat deleniti.</div>
      <div>Magni et ullam animi aspernatur, esse doloremque, itaque, hic perferendis numquam maiores veritatis, sint a laboriosam. Magni vero et dicta ullam a, aut eos voluptate voluptas molestiae voluptatem repellendus pariatur!</div>
      <div>Ipsa nam cupiditate blanditiis totam cum modi neque ex labore molestias accusamus incidunt alias illum laboriosam sed id, a maxime provident laborum veniam. Aut voluptates dolor incidunt, recusandae hic, error!</div>
    </article>
  `,
  styles: ``
})
export class SupermanComponent {
  stock = '';
  constructor(private ar:ActivatedRoute){
    // emtpy
  }
  ngOnInit(){
    this.stock = this.ar.snapshot.params['quantity'];
  }
}
