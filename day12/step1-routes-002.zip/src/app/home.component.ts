import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <h2> Justice League Heroes Component </h2>
    <article>
      <div>Welcome to jutice league heroes home page</div>
    </article>
  `,
  styles: ``
})
export class HomeComponent {

}
