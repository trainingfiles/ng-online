import { Component } from '@angular/core';

@Component({
  selector: 'app-cyborg',
  template: `
    <h2> Cyborg Component works! </h2>
    <article>
      <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro minus voluptas voluptates fugit voluptatibus aliquid soluta eveniet, ipsum facilis reiciendis! Sequi nisi fugiat tenetur architecto quo, molestiae officiis repellat deleniti.</div>
      <div>Iusto, ab harum expedita. Repellat perspiciatis rem sequi quibusdam deserunt, sapiente enim numquam eligendi, voluptas pariatur voluptates vero ab, iusto sunt. Fuga temporibus cupiditate accusantium doloribus, suscipit ab distinctio dolore!</div>
      <div>Ipsa nam cupiditate blanditiis totam cum modi neque ex labore molestias accusamus incidunt alias illum laboriosam sed id, a maxime provident laborum veniam. Aut voluptates dolor incidunt, recusandae hic, error!</div>
    </article>
  `,
  styles: ``
})
export class CyborgComponent {

}
