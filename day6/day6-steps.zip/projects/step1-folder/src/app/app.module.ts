import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FirstComp } from './first.component';

@NgModule({
  /* declare components, pipes, directives that are used in this application */
  declarations: [ AppComponent, FirstComp ],
  /* list of external modules that are used in this application */
  imports: [ BrowserModule ],
  /* logic or data that can be share across multiple components used in this application */
  providers: [],
  /* main component of application */
  bootstrap: [ AppComponent ]
})
export class AppModule { }
