import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>Welcome to your life</h1>
  <app-first></app-first>
  `
})
export class AppComponent {
  title = 'step1-folder';
}
