import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>{{title}}</h1>
    <h2 innerHTML="{{title}}"></h2>
    <h3 [innerHTML]="title"></h3>
    <h4 [innerText]="title"></h4>
    <h5 [textContent]="title"></h5>
    <h6 bind-innerHTML="title"></h6>
    <br>
    <input value="{{title}}" type="text">
    <br>
    <input [value]="title" type="text">
    <br>
    <input bind-value="title" type="text">
    <br>
    <input bind-value="power" type="range">
    <br>
    <input [checked]="agree" type="checkbox">
    <br>
    <button [disabled]="agree">Click Me</button>
    <br>
    <input [value]="getRandomPower()" type="range">
    <div [class]="selecteStyle">Welcome to your life</div>
  `,
  styles: [`
    .redbox{
      width : 200px;
      height : 60px;
      background-color : crimson;
      text-align : center;
      line-height : 60px;
      font-family : 'arial';
    }
    .greenbox{
      width : 200px;
      height : 60px;
      background-color : darkseagreen;
      text-align : center;
      line-height : 60px;
      font-family : 'arial';
    }
  `]
})
export class AppComponent {
  title:string = 'Welcome to Step2-Binding !';
  power:number = 95;
  agree:boolean = true;
  selecteStyle:string = "greenbox";
  getRandomPower(){
    return Math.round( Math.random() * 100 );
  }
}
