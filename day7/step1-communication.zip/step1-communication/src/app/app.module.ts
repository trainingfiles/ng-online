import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ChildComp } from './child.component';

@NgModule({
  /* declare components pipes and directives */
  declarations: [ AppComponent, ChildComp ],
  /* import external modules */
  imports: [ BrowserModule, FormsModule ],
  /* logic or data that is shared between components */
  providers: [],
  /* is the array main components */
  bootstrap: [AppComponent]
})
export class AppModule { }
