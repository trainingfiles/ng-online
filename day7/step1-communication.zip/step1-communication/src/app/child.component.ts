import { Component, EventEmitter, Input, Output } from "@angular/core";
import { Login } from "./login";

@Component({
    selector : "app-child",
    /* inputs : ['inputValue','powerValue'], */
    /* outputs : [], */
    template : `
    <div class="box">
        <h2>Child Component</h2>
        <h3>Input Value {{inputValue}}</h3>
        <h3>Power Value {{powerValue * 2}}</h3>
        <ng-content select="h3"></ng-content>
        <ng-content select="h1"></ng-content>
        <ng-content select="button"></ng-content>
        <ng-content select="ul"></ng-content>
        <ng-content select="p.player"></ng-content>
        <hr>
        <ng-content></ng-content>
        <input #uname type="text">
        <input #upass type="text">
        <button (click)="clickHandler(uname.value,upass.value)">Make Child Event Happen</button>
    </div>
    `,
    styles : [`
        .box{
            border : 1px solid grey;
            background-color : silver;
            padding : 10px;
            font-family : sans-serif;
        }
    `]
})
export class ChildComp{
    
    /* to accept values from parent */
    @Input('herovalue') inputValue:string = "default value";
    @Input('heropower') powerValue:number=0;
    /* to send values to parent */
    @Output('childevent') childCompEvent:EventEmitter<Login> = new EventEmitter();

    clickHandler(val1:any, val2:any){
        // alert("alert in child component");
        // this.childCompEvent.emit(val);
        let userinfo:Login = new Login(val1,val2);
        this.childCompEvent.emit(userinfo);
    }
} 


