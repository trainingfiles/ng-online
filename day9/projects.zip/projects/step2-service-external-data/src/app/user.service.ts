import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class UserService{

   userdata = {};
   constructor(private http:HttpClient){
    // empty
    }
   getData(){
    // return this.data;
    return this.http.get("https://reqres.in/api/users?page=1");
    // return this.userdata;
   }
}