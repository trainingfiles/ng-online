import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-grid',
  template: `
  <h2>Grid Component Version : {{ compversion }}</h2>
    <table class="table">
      <thead  class="table-dark">
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>Poster</th>
          <th>Full Name</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
          <th>Movies List</th>
        </tr>
      </thead>
      <tbody>
          @for(hero of data; track hero.sl){
                <tr>
                <td>{{ hero.sl }}</td>
                <td>{{ hero.title | uppercase | lowercase | titlecase }}</td>
                <td>
                    <img width="50" [src]="hero.poster" [alt]="hero.title">
                </td>
                <td>{{ hero.firstname+" "+hero.lastname }}</td>
                <td>{{ hero.city }}</td>
                <td>{{ hero.ticketprice | currency : "INR" : "code" : "1.2-3" }}</td>
                <td>{{ hero.releasedate | date : "dd - MMMM - yyyy" }}</td>
                <td>
                  @for(movie of hero.movieslist; track movie.title){
                    <img class="m-1" width="50" src="{{movie.poster}}" [alt]="movie.title">
                  }
              </td>
            </tr>
            }
      </tbody>
    </table>
  `,
  styles: ``
})
export class GridComponent {
 // @Input('griddata') data:any = []
 data:any = [];
 compversion = 0;
 // hs:HeroService = new HeroService();
 constructor(public hs:HeroService){
   this.data = this.hs.getdata();
   this.compversion = this.hs.getversion();
 }
}
