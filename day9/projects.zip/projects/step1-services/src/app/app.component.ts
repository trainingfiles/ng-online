import { Component } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-root',
/*   providers : [HeroService], */
  template: `
    <div class="container">
    <h1>Welcome to {{title}}!</h1>
    <app-header></app-header>
    <hr>
    <app-grid></app-grid>
    </div>
  `,
  /* styles: [`
    td img{
      margin : 2px;
    }
    `] */
})
export class AppComponent {
  title = 'Services in Angular';
}
